import React from "react";
import { View, Text, StyleSheet, ScrollView, ImageBackground } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

export default function App() {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <ImageBackground
        source={{
          uri: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?auto=format&fit=crop&w=1050&q=80",
        }}
        style={styles.background}
        imageStyle={{ opacity: 0.25 }}
      >
        {/* Overlay Gradient for Depth */}
        <LinearGradient
          colors={["rgba(10,0,40,0.9)", "rgba(0,0,0,0.8)"]}
          style={styles.overlay}
        />

        {/* Header */}
        <Text style={styles.header}>🚀 Student Profile 🌌</Text>

        {/* Main Info Card */}
        <LinearGradient
          colors={["#4b6cb7", "#182848"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.card}
        >
          <Text style={styles.label}>Name:</Text>
          <Text style={styles.info}>Andree Dave G. Teodoro</Text>

          <Text style={styles.label}>Age:</Text>
          <Text style={styles.info}>20</Text>

          <Text style={styles.label}>Course / Year / Section:</Text>
          <Text style={styles.info}>BS Computer Science / 3rd Year / 3-3</Text>

          <Text style={styles.label}>About Me:</Text>
          <Text style={styles.info}>
            I’m a passionate CS student who loves learning about software development and UI
            design. I do a lot of different things in life like running and poetry.
          </Text>

          <Text style={styles.label}>Achievements:</Text>
          <Text style={styles.info}>
            - President’s Lister 2024{"\n"}- Participant in Cold Start Hackathon{"\n"}- Completed
            several coding bootcamps
          </Text>

          <Text style={styles.label}>Skills:</Text>
          <Text style={styles.info}>
            - JavaScript / React Native{"\n"}- HTML / CSS{"\n"}- UI/UX Design{"\n"}- Git & Version
            Control{"\n"}- Flutter & Flutterflow{"\n"}- SQL{"\n"}- Figma & Framer{"\n"}- Supabase{"\n"}-
            Firebase
          </Text>
        </LinearGradient>

        {/* Quote Card */}
        <LinearGradient
          colors={["#283048", "#859398"]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.quoteCard}
        >
          <Text style={styles.quote}>“In the Endless sky, I swim” 🌠</Text>
        </LinearGradient>
      </ImageBackground>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
  },
  background: {
    flex: 1,
    alignItems: "center",
    justifyContent: "flex-start",
    paddingVertical: 60,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
  },
  header: {
    fontSize: 34,
    fontWeight: "900",
    color: "#fff",
    marginBottom: 25,
    textShadowColor: "#00e0ff",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 15,
    letterSpacing: 2,
  },
  card: {
    width: "85%",
    borderRadius: 25,
    padding: 25,
    shadowColor: "#00e0ff",
    shadowOpacity: 0.7,
    shadowRadius: 20,
    elevation: 10,
    borderWidth: 1,
    borderColor: "#fff",
    marginBottom: 35,
  },
  label: {
    fontSize: 18,
    fontWeight: "800",
    color: "#fff",
    marginTop: 10,
    textTransform: "uppercase",
  },
  info: {
    fontSize: 16,
    color: "#dfe6e9",
    lineHeight: 22,
    marginBottom: 5,
    fontWeight: "500",
  },
  quoteCard: {
    width: "80%",
    borderRadius: 20,
    padding: 20,
    marginTop: 10,
    shadowColor: "#66a6ff",
    shadowOpacity: 0.8,
    shadowRadius: 10,
    elevation: 10,
  },
  quote: {
    fontSize: 18,
    color: "#fff",
    fontStyle: "italic",
    textAlign: "center",
    textShadowColor: "#000",
    textShadowRadius: 6,
  },
});
